//
//  CheckAvailabilityHeaderView.swift
//  Fringe
//
//  Created by Dharmani Apps on 21/08/21.
//

import UIKit

class CheckAvailabilityHeaderView : UIView {
    
}
