//
//  ProfileViewForTitle.swift
//  SessionControl
//
//  Created by Apple on 15/04/21.
//  Copyright © 2021 dharmesh. All rights reserved.
//

import UIKit
import Toucan

class ProfileViewForTitle: UIView {
    
    
    @IBOutlet weak var titleLbl: FGBaseLabel!
    //------------------------------------------------------
    
    //MARK: Init
    
    override class func awakeFromNib() {
        super.awakeFromNib()
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        //imgProfile.circle()
    }
    
    //------------------------------------------------------
}
