//
//  ViewController.swift
//  Fringe
//
//  Created by Dharmani Apps on 10/08/21.
//
import UIKit
import Foundation

class ViewController : UIViewController {
    
    //------------------------------------------------------
    
    //MARK: IBOutlets
    
    
    //------------------------------------------------------
    
    //MARK: Vsribles
    
    
    
    //------------------------------------------------------
    
    //MARK: Memory Management Method
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    //------------------------------------------------------
    
    deinit { //same like dealloc in ObjectiveC
        
    }
    
    //------------------------------------------------------
    
    //MARK: Custome
    
    
    //------------------------------------------------------
    
    //MARK: Action
    
    //------------------------------------------------------
    
    //MARK: UIViewController
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    //------------------------------------------------------
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    //------------------------------------------------------
}
