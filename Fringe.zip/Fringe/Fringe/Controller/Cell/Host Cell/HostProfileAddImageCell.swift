//
//  HostProfileAddImageCell.swift
//  Fringe
//
//  Created by Dharmani Apps on 01/09/21.
//

import UIKit

class HostProfileAddImageCell: UICollectionViewCell {
    
    @IBOutlet weak var btnDelete: UIButton!
    @IBOutlet weak var addImage: UIImageView!
}
