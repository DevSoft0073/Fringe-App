//
//  GolfProfileAddImagesCell.swift
//  Fringe
//
//  Created by Dharmani Apps on 24/08/21.
//

import UIKit

class GolfProfileAddImagesCell: UICollectionViewCell {
    
    @IBOutlet weak var addImage: UIImageView!
    @IBOutlet weak var btnDelete: UIButton!
}
